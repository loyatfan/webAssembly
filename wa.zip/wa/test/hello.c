#include <stdio.h>
#include <emscripten/emscripten.h>

int main(int argc, char ** argv) {
    // printf("Hello ss World\n");
}

#ifdef __cplusplus
extern "C" {
#endif

int EMSCRIPTEN_KEEPALIVE fibonacci(int n) {
    if (n <= 1) {
        return n;
    } else {
        return fibonacci(n-1) + fibonacci(n-2);
    }
}

#ifdef __cplusplus
}
#endif
