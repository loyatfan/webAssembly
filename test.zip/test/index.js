function SliderInput() {
    var self = Reflect.construct(HTMLElement, [], this.constructor);

    // 初始化默认配置
    self.config = {
        label: 'Slider Value:',
        min: 0,
        max: 100,
        step: 1,
        value: 50,
    };

    // 创建 shadow DOM
    var shadow = self.attachShadow({ mode: 'open' });

    // 定义整个元素的 HTML 结构
    shadow.innerHTML =
        '<style>' +
        ':host {' +
        'display: block;' +
        'font-family: "Arial", sans-serif;' +
        'margin: 20px;' +
        '}' +
        'label {' +
        'display: block;' +
        'margin-bottom: 8px;' +
        '}' +
        'input[type="range"] {' +
        'width: 100%;' +
        '}' +
        '</style>' +
        '<label>' + self.config.label + ' ' + self.config.value + '</label>' +
        '<input type="range" value="' + self.config.value + '" min="' + self.config.min + '" max="' + self.config.max + '" step="' + self.config.step + '">';

    // 获取组件的元素
    self.inputElement = shadow.querySelector('input[type="range"]');
    self.labelElement = shadow.querySelector('label');

    // 添加事件监听器
    self.inputElement.addEventListener('input', function () {
        self.config.value = parseFloat(self.inputElement.value);
        self.updateLabel();
    });

    return self;
}

SliderInput.prototype = Object.create(HTMLElement.prototype);
SliderInput.prototype.constructor = SliderInput;

SliderInput.prototype.connectedCallback = function () {
    this.updateInput();
    this.updateLabel();
};

SliderInput.prototype.configure = function (config) {
    // 合并配置
    for (var key in config) {
        if (config.hasOwnProperty(key)) {
            this.config[key] = config[key];
        }
    }

    this.updateInput();
    this.updateLabel();
};

SliderInput.prototype.getValue = function (attribute) {
    return this.config[attribute];
};

SliderInput.prototype.setValue = function (attribute, value) {
    // 设置组件的属性
    this.config[attribute] = value;
    this.updateInput();
    this.updateLabel();
};

SliderInput.prototype.updateInput = function () {
    // 更新 input 元素的值
    this.inputElement.min = this.config.min;
    this.inputElement.max = this.config.max;
    this.inputElement.step = this.config.step;
    this.inputElement.value = this.config.value;
};

SliderInput.prototype.updateLabel = function () {
    this.labelElement.textContent = this.config.label + ' ' + this.config.value;
};

customElements.define('slider-input', SliderInput);