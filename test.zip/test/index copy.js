function CustomSlider() {
    this.config = {
        minValue: 0,
        maxValue: 100,
        value: 50,
        label: 'Slider:'
    };
    this.render();
}

CustomSlider.prototype = {
    observedAttributes: ['config'],

    attributeChangedCallback: function (name, oldValue, newValue) {
        if (name === 'config') {
            this.config = JSON.parse(newValue);
            this.render();
        }
    },

    connectedCallback: function () {
        this.render();
    },

    render: function () {
        $(this).html('\
            <style>\
              :host {\
                display: block;\
                width: 300px;\
              }\
              input[type="range"] {\
                width: 100%;\
              }\
            </style>\
            <label for="slider">' + this.config.label + '</label>\
            <input\
              type="range"\
              id="slider"\
              name="slider"\
              min="' + this.config.minValue + '"\
              max="' + this.config.maxValue + '"\
              value="' + this.config.value + '"\
              oninput="handleInput.call(this)">\
            <span>' + this.config.value + '</span>');
    }
};

function handleInput() {
    this.config.value = $(this).find('input[type="range"]').val();
    $(this).trigger('change', this.config.value);
    this.render();
}

// 公共方法用于设置value
CustomSlider.prototype.setValue = function (newValue) {
    this.config.value = newValue;
    this.render();
};

// 公共方法用于获取value
CustomSlider.prototype.getValue = function () {
    return this.config.value;
};

customElements.define('custom-slider', CustomSlider);
